// E:/zodiac360/backend/src/engine/D1/d1Engine.js

const { SIGN_DATA, PLANET_DATA, HOUSE_THEMES, SPECIAL_ASPECTS } = require('./d1Rules');

function analyzeD1Chart(payload) {
  const d1Data = payload.data ? payload.data : payload;

  const lagna = d1Data.lagna;
  const lagnaId = lagna.signId;
  const lagnaMeta = SIGN_DATA[lagnaId];
  const lagnaLord = lagnaMeta.ruler;
  const lagnaLordData = d1Data.grahas[lagnaLord];
  const lagnaLordHouse = lagnaLordData.house;

  // सभी 12 भावों पर दृष्टियों (Aspects) की गणना
  const houseAspects = {};
  for (let i = 1; i <= 12; i++) houseAspects[i] = [];

  for (const [planet, pData] of Object.entries(d1Data.grahas)) {
    const fromHouse = pData.house;
    const offsets = SPECIAL_ASPECTS[planet] || [7];
    offsets.forEach(offset => {
      let target = ((fromHouse - 1 + offset - 1) % 12) + 1;
      houseAspects[target].push(planet);
    });
  }

  // 12 भावों का लेयर-वाइज़ विश्लेषण
  const houseAnalysis = {};
  for (let h = 1; h <= 12; h++) {
    const signId = ((lagnaId - 1 + (h - 1)) % 12) + 1;
    const signInfo = SIGN_DATA[signId];
    const lord = signInfo.ruler;
    const lordPlacement = d1Data.grahas[lord].house;
    const occupants = d1Data.analysis.houseOccupancy[h.toString()] || [];
    const aspects = houseAspects[h] || [];

    let details = [];

    // भावेश की स्थिति
    details.push(`इस भाव के स्वामी ${PLANET_DATA[lord].hindi} (${lord}) ${lordPlacement}वें भाव में स्थित हैं, जो दर्शाता है कि ${HOUSE_THEMES[lordPlacement].impact}`);

    // ग्रह उपस्थिति
    if (occupants.length > 0) {
      const occupantDesc = occupants.map(p => {
        const dignity = d1Data.analysis.planetaryDignities[p]?.dignity || "Neutral";
        const retro = d1Data.grahas[p]?.isRetrograde ? " (वक्री)" : "";
        return `${PLANET_DATA[p].hindi} [${p}] (${dignity}${retro} - ${PLANET_DATA[p].trait})`;
      }).join(", ");
      details.push(`इस भाव में सीधे उपस्थित ग्रह: ${occupantDesc}।`);
    } else {
      details.push("इस भाव में कोई प्रत्यक्ष ग्रह नहीं है, अतः इसका फल भावेश की स्थिति और दृष्टियों पर आधारित रहेगा।");
    }

    // दृष्टियां
    if (aspects.length > 0) {
      const aspectDesc = aspects.map(p => `${PLANET_DATA[p].hindi}`).join(", ");
      details.push(`इस भाव पर ${aspectDesc} की दृष्टि पड़ रही है जो अतिरिक्त प्रभाव जोड़ती है।`);
    }

    houseAnalysis[`house_${h}`] = {
      title: HOUSE_THEMES[h].title,
      domain: HOUSE_THEMES[h].domain,
      rulingSign: `${signInfo.name} (${signInfo.hindi})`,
      signLord: `${lord} (Placed in House ${lordPlacement})`,
      occupants: occupants,
      aspectingPlanets: aspects,
      synthesis: details.join(" ")
    };
  }

  // कोर पर्सनालिटी व बॉडी समरी
  const lagnaOccupants = d1Data.analysis.houseOccupancy["1"] || [];
  let bodySummary = `${lagnaMeta.hindi} लग्न (${lagnaMeta.element} तत्व) के आधार पर: ${lagnaMeta.body}`;
  if (lagnaOccupants.length > 0) {
    bodySummary += ` लग्न में ${lagnaOccupants.map(p => PLANET_DATA[p].hindi).join(", ")} की स्थिति व्यक्तित्व में विशेष आकर्षण और सौम्यता जोड़ती है।`;
  }

  let personalitySummary = `मूल मानसिक प्रकृति: ${lagnaMeta.personality} लग्नेश (${PLANET_DATA[lagnaLord].hindi}) के ${lagnaLordHouse}वें भाव में होने से व्यक्ति की जीवन प्राथमिकता ${HOUSE_THEMES[lagnaLordHouse].domain} रहेगी।`;

  return {
    success: true,
    statusCode: 200,
    chartType: "D1 (Lagna / Rashi Chart)",
    meta: {
      dob: d1Data.meta.inputDate,
      tob: d1Data.meta.inputTime,
      ascendant: `${lagna.sign} (${lagna.signHindi})`,
      ascendantDegree: lagna.degreeInSign,
      nakshatra: `${lagna.nakshatra} (चरण ${lagna.charan})`,
      ayanamsha: `${d1Data.meta.ayanamshaUsed} (${d1Data.meta.ayanamshaValue})`
    },
    coreSynthesis: {
      bodyAndConstitution: bodySummary,
      personalityAndTemperament: personalitySummary,
      overallLifeDirection: HOUSE_THEMES[lagnaLordHouse].impact
    },
    houseWiseDetailedAnalysis: houseAnalysis,
    activeYogasAndDoshas: (d1Data.analysis.yogasAndDoshas || []).map(y => ({
      name: y.name,
      type: y.type,
      impact: y.description
    }))
  };
}

module.exports = {
  analyzeD1Chart
};