const { D30_RULES } = require('./d30Rules');

function interpretD30Chart(d30) {
  if (!d30?.lagna || !d30?.planets) {
    throw new Error('Valid D30 lagna and planets are required.');
  }

  const planetInsights = {};
  for (const [name, p] of Object.entries(d30.planets)) {
    const rule = D30_RULES[p.segmentLord] || null;
    planetInsights[name] = {
      planet: name,
      d30Sign: p.d30Sign,
      d30SignHindi: p.d30SignHindi,
      house: p.house,
      segmentLord: p.segmentLord,
      themes: rule?.themes || [],
      positive: rule?.positive || null,
      retrograde: Boolean(p.isRetrograde)
    };
  }

  return {
    chart: 'D30',
    chartName: 'Trimshamsha Chart',
    purpose: 'Difficulties, vulnerabilities, misfortunes, resilience and recovery patterns.',
    lagna: d30.lagna,
    planets: planetInsights
  };
}

module.exports = { interpretD30Chart };
