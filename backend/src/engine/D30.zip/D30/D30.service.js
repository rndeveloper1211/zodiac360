'use strict';

const { getUtcDate } = require('../../utils/time.util');
const { getD1Chart } = require('../D1/D1.engine');
const { processD30Chart } = require('./D30.engine');

function generateD30Report({ date, time, lat, lon, timezone = 5.5 }) {
  if (!date || !time || lat === undefined || lon === undefined) {
    throw new Error('date, time, lat and lon are required.');
  }

  const latitude = Number(lat);
  const longitude = Number(lon);
  const tz = Number(timezone);

  if (!Number.isFinite(latitude)) throw new Error('Invalid latitude.');
  if (!Number.isFinite(longitude)) throw new Error('Invalid longitude.');
  if (!Number.isFinite(tz)) throw new Error('Invalid timezone.');

  const utcDate = getUtcDate(date, time, tz);
  const d1 = getD1Chart(utcDate, latitude, longitude);
  const chart = processD30Chart(d1);
console.log('D1_CHART_DATA=>>>>')
console.log(d1)
console.log('D1_CHART_DATA=>>>>')

  return {
    meta: {
      chart: 'D30',
      chartName: 'Trimshamsha Chart',
      calculationSystem: 'Parashari Trimshamsha',
      inputDate: date,
      inputTime: time,
      latitude,
      longitude,
      timezoneOffset: tz,
      utcTimestamp: utcDate.toISOString(),
      ayanamshaUsed: 'Lahiri',
      ayanamshaValue: d1.ayanamsha
    },
    lagna: chart.lagna,
    planets: chart.planets,
    houses: chart.houses
  };
}

function processExistingD1ToD30(d1Chart) {
  return processD30Chart(d1Chart);
}

module.exports = {
  generateD30Report,
  processExistingD1ToD30
};
