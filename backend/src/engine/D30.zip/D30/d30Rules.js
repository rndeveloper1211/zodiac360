/**
 * D30 interpretation rules.
 * Calculation is kept separate from interpretation.
 */

const D30_RULES = {
  Mars: {
    themes: ['accidents', 'injury', 'conflict', 'acute events', 'sudden aggression'],
    positive: 'साहस, recovery और संकट में action लेने की क्षमता।'
  },
  Saturn: {
    themes: ['chronic difficulty', 'delay', 'loss through circumstances', 'persistent obstacles'],
    positive: 'धैर्य, सहनशीलता और कठिन समय को लंबे समय तक संभालने की क्षमता।'
  },
  Jupiter: {
    themes: ['protection', 'wisdom', 'support', 'recovery'],
    positive: 'संकट में संरक्षण, सही सलाह और recovery support।'
  },
  Mercury: {
    themes: ['nervous strain', 'calculation errors', 'stress through communication'],
    positive: 'समस्या को समझकर practical solution निकालने की क्षमता।'
  },
  Venus: {
    themes: ['comfort', 'relationships', 'material ease', 'sensual vulnerabilities'],
    positive: 'सुख-सुविधा, संबंधों और सामाजिक support से राहत।'
  }
};

module.exports = { D30_RULES };
